from . import conformer
from . import eeg_1d
from . import eeg_transformer
from . import wavenet
from . import model